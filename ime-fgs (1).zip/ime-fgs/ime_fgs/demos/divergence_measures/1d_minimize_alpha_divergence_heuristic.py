# For research and educational use only, do not distribute without permission.
#
# Created by:
# Eike Petersen, Felix Vollmer with contribution from institute members and students
#
# University of Lübeck
# Institute for Electrical Engineering in Medicine
#
import numpy as np
import scipy.stats as spst
import matplotlib.pyplot as plt
from ime_fgs.divergence_measures import KL_projection_gauss

zero_bound = 1e-16
inf_bound = 1e16

mu1 = np.array([5])
cov1 = np.array([10])

mu2 = np.array([-2])
cov2 = np.array([1])

dist1 = spst.multivariate_normal(mean=mu1, cov=cov1, allow_singular=False)
dist2 = spst.multivariate_normal(mean=mu2, cov=cov2, allow_singular=False)

N = 100000
x1 = np.linspace(-20.0, 20.0, N)
dx = np.tile(np.mean(np.ediff1d(x1)), N)

pos = x1
dist1_pdf = np.asarray(dist1.pdf(pos))
dist2_pdf = np.asarray(dist2.pdf(pos))

p_pdf = (0.5 * (dist1_pdf + dist2_pdf))
np.trapz(p_pdf * dx)

fig1 = plt.figure()
ax = fig1.add_subplot(111)
ax.plot(x1, p_pdf)

# Initialize with simple moment matched q
q = KL_projection_gauss(p_pdf, x1)
q_pdf = q.pdf(pos)
ax.plot(x1, q_pdf)


q_pdf = p_pdf
# plt.show()

#
alpha_range = [3, 2.475]
alpha_vals = np.array([alpha_range[0]])
# alpha_vals  = np.linspace(alpha_range[0], alpha_range[1], 100)

damping = 0.2
Niter = 100

q_pdf_alpha = np.zeros((len(alpha_vals), len(q_pdf)))

for jj in range(0, len(alpha_vals)):
    alpha = alpha_vals[jj]

    for ii in range(0, Niter):
        p_pdf[p_pdf > inf_bound] = inf_bound
        p_pdf[p_pdf < zero_bound] = zero_bound
        q_pdf[q_pdf > inf_bound] = inf_bound
        q_pdf[q_pdf < zero_bound] = zero_bound

        pq_alpha_pdf = (p_pdf / q_pdf)**(alpha) * q_pdf

        pq_alpha_pdf[pq_alpha_pdf > inf_bound] = inf_bound
        pq_alpha_pdf[pq_alpha_pdf < zero_bound] = zero_bound

        # ax.plot(x1, p_alpha_pdf)

        # q_alpha_pdf = q_pdf**(1.0 - alpha)

        # ax.plot(x1, q_alpha_pdf)
        # plt.show()

        # q_prime = KL_projection_gauss(p_alpha_pdf*q_alpha_pdf, x1)
        q_prime = KL_projection_gauss(pq_alpha_pdf, x1)
        q_prime_pdf = q_prime.pdf(x1)
        q_pdf = (q_pdf**damping) * (q_prime_pdf**(1.0 - damping))

    q_pdf_alpha[jj, :] = q_pdf
    ax.plot(x1, q_pdf_alpha[jj])

# ax.plot(x1, q_pdf_alpha[-1])
plt.show()
